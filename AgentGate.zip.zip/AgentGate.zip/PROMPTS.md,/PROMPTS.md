# PROMPTS.md — Assignment Instructions

## Instructions Given to the AI Agent

The following instructions were provided by the student (PGD202565984) to build this project:

---

Build a small, working local website called "JPMorgan Chase Agent Gatekeeper" for my assignment. My enrolment number is PGD202565984. Show it on the main screen.

Use Python's standard library only. Run locally at http://127.0.0.1:5000. Do not deploy it, connect to a real bank, handle real account data, or make real payments. Use fictional test data only.

The website must let me:
- Enter a customer name, agent name, action and amount in rupees.
- Register an agent to a customer and choose which actions it may request.
- Revoke an agent and save the revocation date and time.
- Submit a request and see ALLOW, ASK CUSTOMER or BLOCK, with the rule number and a clear reason.
- Preserve agent registration and revocation after restarting the server.
- Record every request, decision, registration and revocation in local files. For each request, save date/time, customer, agent, action, amount, decision, rule number and reason.

Support these bank actions: view balance, pay a bill, transfer money.

Apply these rules in order:
R1. An agent not registered to that customer is BLOCKED.
R2. A revoked agent is always BLOCKED, even if previously registered.
R3. An action outside the agent's permitted actions is BLOCKED.
R4. A permitted view-balance request is ALLOWED.
R5. A permitted bill payment or transfer of ₹5,000 or less is ALLOWED.
R6. A permitted bill payment or transfer above ₹5,000 requires the customer's confirmation: ASK CUSTOMER.
R7. Reject invalid or negative amounts with a clear message and do not process the request.

The ₹5,000 limit is a prototype policy choice: smaller payments are convenient, while larger ones need the customer's confirmation.

Create README.md with simple instructions to start and stop the local website and run the tests. Create PROMPTS.md listing the instructions I gave you, with a blank section where I can describe one thing I personally checked or changed. Do not invent my personal work.

Include these six test cases and expected results in README.md:
1. Registered agent viewing balance, amount ₹0 — ALLOW, R4.
2. Unknown agent viewing balance — BLOCK, R1.
3. Registered agent transferring ₹6,000 — ASK CUSTOMER, R6.
4. Registered agent paying a bill of ₹2,000 — ALLOW, R5.
5. Revoke a registered agent, then have it view balance — BLOCK, R2.
6. Registered agent transferring ₹0 — ALLOW, R5.

First show me a short plan and wait for my approval. After I approve, build the website, run it locally, open it in my browser, and check all six cases against their expected results. Fix any problems you find and tell me where the audit log is saved.

---

## My Personal Check / Change

*(Write one thing you personally checked or changed here — do not leave blank when submitting.)*

---
